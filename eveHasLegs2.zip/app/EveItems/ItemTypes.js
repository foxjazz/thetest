"use strict";
exports.ItemTypeDescriptor = { id: Number, id_str: String,
    marketGroup: { href: String, id: Number, id_str: String, },
    Type: { id_str: String, href: String, id: Number, name: String } };
//# sourceMappingURL=ItemTypes.js.map