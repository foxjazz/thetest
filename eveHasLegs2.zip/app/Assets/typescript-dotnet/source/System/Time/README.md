# Intention
These classes should behave as if they are read only much like the .NET DateTime class works.  This way a value which may be reference somewhere else does not change unexpected.



