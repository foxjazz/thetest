# System.Net

Contains many useful interfaces to model out Net based classes.

***Is a work in progress.***