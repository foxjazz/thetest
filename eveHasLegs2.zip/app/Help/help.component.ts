import {Component} from '@angular/core';
@Component({
  selector: 'sel-help',
  templateUrl: 'app/Help/help.component.html',
  //styleUrls: ['app/PriceBoard/canvas.css'],
  
})
export class HelpComponent  {}