"use strict";
var PriceData = (function () {
    function PriceData() {
    }
    return PriceData;
}());
exports.PriceData = PriceData;
//# sourceMappingURL=pricetypes.js.map